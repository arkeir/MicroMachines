Dowloaded from PlanIt 3D 

http://www.planit3d.com

------------------------

Mesh originally created by One-Commune.

FREE to use in personal works only unless otherwise noted.

They may not be used commercially.  The exception is that you may use them in an image that you intend to sell commercially, as long as the One-Commune model (mesh) is not the primary focus.
